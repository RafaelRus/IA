'''
En este archivo, defino funciones 
que me permitiran ahorrar lineas de
codigo en gameProblem.py
'''

import math

def tolists(state):
    '''Funcion que transforma todas las tuplas de un estado en lista (devuelve otra estructura diferente)'''
    state_ret=list(state)
    clientes=[]
    for i in state[3]:
        clientes.append(list(i))
    state_ret[3]=clientes
    return state_ret



def totuples(state):
    '''Transforma todas las listas de un estado en tuplas'''
    state_ret=state
    clientes=[]
    for i in state_ret[3]:
        clientes.append(tuple(i))
    state_ret[3]=tuple(clientes)
    state_ret=tuple(state_ret)
    return state_ret

def manhattan(x1,y1,x2,y2):
    '''distancia de Manhattan'''
    return abs(x2-x1)+abs(y2-y1)


def euclidean(x1,y1,x2,y2):
    '''Distancia euclidea entre 2 puntos del mapa'''
    value=math.pow(abs(x2-x1),2) + math.pow(abs(y2-y1),2)
    return math.sqrt(value)

def minkowski(x1,x2,y1,y2,q):
    '''Distancia minkowski entre 2 puntos del mapa'''
    '''Si q=2, tenemos la distancia euclidea.'''
    value=math.pow(abs(x2-x1),q) + math.pow(abs(y2-y1),q)
    return math.pow(value,1/q)
