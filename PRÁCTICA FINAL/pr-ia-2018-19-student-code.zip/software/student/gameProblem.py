
'''
    Class gameProblem, implements simpleai.search.SearchProblem
'''


from simpleai.search import SearchProblem
# from simpleai.search import breadth_first,depth_first,astar,greedy
import simpleai.search

from misfunciones import *

class GameProblem(SearchProblem):

    # Object attributes, can be accessed in the methods below

    MAP=None
    POSITIONS=None
    INITIAL_STATE=None
    GOAL=None
    CONFIG=None
    AGENT_START=None
    SHOPS=None
    CUSTOMERS=None
    MAXBAGS = 0

    MOVES = ('West','North','East','South','Deliv','Collect')

   # --------------- Common functions to a SearchProblem -----------------

    def actions(self, state):
        '''Returns a LIST of the actions that may be executed in this state
        '''
        actions = []

        #Evaluar Collect
        if self.MAP[state[0]][state[1]][0]=='pizza':
            if state[2]<self.MAXBAGS and state[3]!=():
                actions.append('Collect')

        #Evaluar Deliv
        if 'customer' in self.MAP[state[0]][state[1]][0] :
            if state[3] != () and state[2]>0:
                for i in state[3]:
                    if i[0]==state[0] and i[1]==state[1]:
                        actions.append('Deliv')

        #Evaluar North
        if state[1]-1>=0 and state[1]-1<self.CONFIG['map_size'][1]:
            if self.MAP[state[0]][state[1]-1][0] != 'building':
                actions.append('North')

        #Evaluar South
        if state[1]+1>=0 and state[1]+1 <self.CONFIG['map_size'][1]:
            if self.MAP[state[0]][state[1]+1][0] != 'building':
                actions.append('South')

        #Evaluar East
        if state[0]+1>=0 and state[0]+1 <self.CONFIG['map_size'][0]:
            if self.MAP[state[0]+1][state[1]][0] != 'building':
                actions.append('East')

        #Evaluar West
        if state[0]-1>=0 and state[0]-1 <self.CONFIG['map_size'][0]:
            if self.MAP[state[0]-1][state[1]][0] != 'building':
                actions.append('West')

        return actions


    def result(self, state, action):
        '''Returns the state reached from this state when the given action is executed
        '''
        next_state = tolists(state)

        #Collect
        if action=='Collect':
            next_state[2]=self.MAXBAGS
            return totuples(next_state)

        if action=='Deliv':
            for i in next_state[3]:
                if i[0]==next_state[0] and i[1]==next_state[1]:
                    if i[2]>next_state[2]:
                        i[2]=i[2]-next_state[2]
                        next_state[2]=0
                        break
                    elif i[2]<=next_state[2]:
                        next_state[2]=next_state[2]-i[2]
                        next_state[3].remove(i)
                        break
            return totuples(next_state)

        if action=='North':
            next_state[1]-=1
            return totuples(next_state)

        if action=='South':
            next_state[1]+=1
            return totuples(next_state)

        if action=='East':
            next_state[0]+=1
            return totuples(next_state)

        if action=='West':
            next_state[0]-=1
            return totuples(next_state)

        #Salvo que haya fallos, no se llega a este punto del programa
        return None


    def is_goal(self, state):
        '''Returns true if state is the final state
        '''
        if state[3] != ():
            return False
        if state[0] != self.AGENT_START[0]:
            return False
        if state[1] != self.AGENT_START[1]:
            return False
        return True


    def cost(self, state, action, state2):
        '''Returns the cost of applying `action` from `state` to `state2`.
           The returned value is a number (integer or floating point).
           By default this function returns `1`.
        '''
        if action=='Collect':
            return 1
        if action=='Deliv':
            return 1

        '''
        AQUI, EN LA PARTE AVANZADA, SE EVALUARAN TIPOS DE TERRENO.
        '''
        if self.MAP[state2[0]][state2[1]][0]=='forest':
            return self.CONFIG['maptiles']['forest']['attributes']['cost']
        if self.MAP[state2[0]][state2[1]][0]=='hills':
            return self.CONFIG['maptiles']['hills']['attributes']['cost']
        if self.MAP[state2[0]][state2[1]][0]=='desert':
            return self.CONFIG['maptiles']['hills']['attributes']['cost']
        if self.MAP[state2[0]][state2[1]][0]=='plains':
            return self.CONFIG['maptiles']['hills']['attributes']['cost']
        return 1


    def heuristic(self, state):
        '''Returns the heuristic for `state`
        '''
        #Si no hay clientes, regresar
        if (state[3]==()):
            return euclidean(state[0],state[1],self.GOAL[0],self.GOAL[1])

        #En el peor de los casos, la heuristica
        #seria la suma de las dimensiones del mapa
        maxdist=self.CONFIG['map_size'][0] + self.CONFIG['map_size'][1]

        #Si la moto tiene pizzas, buscar el cliente mas cercano
        if state[2]>0:
            cl_cercano=maxdist
            for i in state[3]:
                cl_cercano=min(cl_cercano,euclidean(state[0],state[1],i[0],i[1]))
            return cl_cercano

        #Si la moto no tiene pizzas, busca la pizzeria mas cercana.
        if state[2] == 0:
            pz_cercana=maxdist
            for i in self.POSITIONS['pizza']:
                pz_cercana=min(pz_cercana,euclidean(state[0],state[1],i[0],i[1]))
            return pz_cercana



    def setup (self):
        '''This method must create the initial state, final state (if desired) and specify the algorithm to be used.
           This values are later stored as globals that are used when calling the search algorithm.
           final state is optional because it is only used inside the is_goal() method

           It also must set the values of the object attributes that the methods need, as for example, self.SHOPS or self.MAXBAGS
        '''

        print '\nMAP: ', self.MAP, '\n'
	print 'POSITIONS: ', self.POSITIONS, '\n'
	print 'CONFIG: ', self.CONFIG, '\n'

        self.MAXBAGS=self.CONFIG['maxBags']
        customers=[]
        if 'customer3' in self.POSITIONS:
            for i in self.POSITIONS['customer3']:
                x=list(i)
                x.append(3)
                customers.append(tuple(x))

        if 'customer2' in self.POSITIONS:
            for i in self.POSITIONS['customer2']:
                x=list(i)
                x.append(2)
                customers.append(tuple(x))

        if 'customer1' in self.POSITIONS:
            for i in self.POSITIONS['customer1']:
                x=list(i)
                x.append(1)
                customers.append(tuple(x))


        initial_state = (self.AGENT_START[0],self.AGENT_START[1],0,tuple(customers))
        final_state= (self.AGENT_START[0],self.AGENT_START[1],0,() )
        #breadth_first,depth_first,astar
        algorithm= simpleai.search.astar

        return initial_state,final_state,algorithm

    def printState (self,state):
        '''Return a string to pretty-print the state '''

        return str(state)

    def getPendingRequests (self,state):
        ''' Return the number of pending requests in the given position (0-N).
            MUST return None if the position is not a customer.
            This information is used to show the proper customer image.
        '''
        if 'customer' in self.MAP[state[0]][state[1]][0]:
            for i in state[3]:
                if i[0]==state[0] and i[1]==state[1]:
                    return i[2]
            return 0

        return None

    # -------------------------------------------------------------- #
    # --------------- DO NOT EDIT BELOW THIS LINE  ----------------- #
    # -------------------------------------------------------------- #

    def getAttribute (self, position, attributeName):
        '''Returns an attribute value for a given position of the map
           position is a tuple (x,y)
           attributeName is a string

           Returns:
               None if the attribute does not exist
               Value of the attribute otherwise
        '''
        tileAttributes=self.MAP[position[0]][position[1]][2]
        if attributeName in tileAttributes.keys():
            return tileAttributes[attributeName]
        else:
            return None

    def getStateData (self,state):
        stateData={}
        pendingItems=self.getPendingRequests(state)
        if pendingItems >= 0:
            stateData['newType']='customer{}'.format(pendingItems)
        return stateData

    # THIS INITIALIZATION FUNCTION HAS TO BE CALLED BEFORE THE SEARCH
    def initializeProblem(self,map,positions,conf,aiBaseName):
        self.MAP=map
        self.POSITIONS=positions
        self.CONFIG=conf
        self.AGENT_START = tuple(conf['agent']['start'])

        initial_state,final_state,algorithm = self.setup()
        if initial_state == False:
            print ('-- INITIALIZATION FAILED')
            return True

        self.INITIAL_STATE=initial_state
        self.GOAL=final_state
        self.ALGORITHM=algorithm
        super(GameProblem,self).__init__(self.INITIAL_STATE)

        print ('-- INITIALIZATION OK')
        return True

    # END initializeProblem
